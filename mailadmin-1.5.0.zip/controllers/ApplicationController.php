<?php

/**
 * Class Mailadmin_ApplicationController
 */
class Mailadmin_ApplicationController extends Application_Controller_Default
{
    /**
     * @throws Zend_Exception
     */
    public function viewAction()
    {
        $this->loadPartials();
    }

    /**
     * @throws Zend_Exception
     */
    public function loadAction()
    {
        $payload = [
            'title' => p__('mailadmin', 'Admin mailer'),
            'icon' => 'fa-cogs',
        ];

        $this->_sendJson($payload);
    }
}
