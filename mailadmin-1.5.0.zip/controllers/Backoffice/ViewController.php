<?php

/**
 * Class Mailadmin_Backoffice_ViewController
 */
class Mailadmin_Backoffice_ViewController extends Backoffice_Controller_Default
{
    /**
     * @throws Zend_Exception
     */
    public function editmailadminAction()
    {
        $this->loadPartials();
    }

    /**
     * @return $this
     * @throws Zend_Controller_Router_Exception
     * @throws Zend_Session_Exception
     */
    public function sendmailAction()
    {
        $request = $this->getRequest();
        $params = $request->getParams();
        $session = $this->getSession();

        try {
            if (!isset($params['email'])) {
                throw new Siberian_Exception(p__('mailadmin', 'You must select at least one recipient!'));
            }
            foreach ($params['email'] as $email) {
                $mail = new Siberian_Mail();
                $mail->setSubject($params['theme']);
                $mail->setBodyHtml($params['text']);
                $mail->addTo($email);
                $mail->send();
            }

            $session->addSuccess(p__('mailadmin', 'E-mail has been sent to the recipients!'));
        } catch (\Exception $e) {
            $session->addError($e->getMessage());
        }

        $this->_redirect('mailadmin/backoffice_view/editmailadmin');
    }

}
