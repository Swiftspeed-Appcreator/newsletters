<?php

/**
 * @param $bootstrap
 */
$init = static function($bootstrap) {
    Siberian_Module::addMenu("Mailadmin", "mailadmin", __("Mailadmin"), "/mailadmin/backoffice_view/editmailadmin");
};

