App.config(function ($routeProvider) {
    $routeProvider.when(BASE_URL + "/mailadmin/backoffice_view/editmailadmin", {
        controller: 'MailadminController',
        templateUrl: BASE_URL + "/mailadmin/backoffice_view/template"
    });
}).controller("MailadminController", function ($scope, $timeout) {
    $scope.admins = [];
    let link = document.createElement('link');
    link.type = 'text/css';
    link.rel = 'stylesheet';
    link.href = '/app/local/modules/Mailadmin/resources/design/desktop/backoffice/js/jodit/jodit.min.css';
    let script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = '/app/local/modules/Mailadmin/resources/design/desktop/backoffice/js/jodit/jodit.min.js';
    document.getElementsByTagName('head')[0].appendChild(link);
    document.getElementsByTagName('head')[0].appendChild(script);
    $timeout(function () {
        let editor = new Jodit('#editor', {
            height: 500,
            iframe: true
        });
    }, 1000);
});
